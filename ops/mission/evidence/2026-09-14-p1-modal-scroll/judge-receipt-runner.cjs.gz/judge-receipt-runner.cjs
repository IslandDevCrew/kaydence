const assert=require('node:assert/strict'),fs=require('node:fs');
const {chromium}=require('/Users/IDC2.5/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const source=fs.readFileSync('ops/mission/evidence/2026-09-14-p1-modal-scroll-check.cjs','utf8');
const {wheelBottom}=new Function('require','process',`${source.split('(async () => {')[0]};return {wheelBottom}`)(require,{env:{PLAYWRIGHT_MODULE:'/Users/IDC2.5/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright'}});
(async()=>{
 const browser=await chromium.launch();try{
  const page=await browser.newPage({viewport:{width:900,height:600}});await page.goto('http://127.0.0.1:1438');
  const root=page.locator('.nav-list');await root.waitFor();
  await page.evaluate(()=>{const cover=document.createElement('div');cover.style.cssText='position:fixed;inset:0;z-index:9999';document.body.append(cover);});
  const start=Date.now();let failure;
  try{await wheelBottom(page,root);}catch(e){failure={name:e.name,message:e.message,elapsed:Date.now()-start};}
  assert.equal(failure?.name,'TimeoutError');assert(failure.elapsed>=1900&&failure.elapsed<5000);
  assert(await root.evaluate(el=>!('__modalWheelProbe' in el)),'Probe listener state cleaned after missed receipt');
  console.log(JSON.stringify({status:'PASS',scope:'Browser-only occlusion negative, no repository writes',failure,probeClean:true},null,2));
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
