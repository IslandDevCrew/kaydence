const assert = require('node:assert/strict'), fs = require('node:fs');
const { chromium } = require('/Users/IDC2.5/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const dir = process.env.CAPTURE_DIR || '/tmp/kaydence-modal-judge-20260914';
const cp = require('node:child_process');
const style = process.env.PRIVACY_STYLE_REF ? cp.execFileSync('git', ['show', `${process.env.PRIVACY_STYLE_REF}:apps/desktop/src/views/PrivacyView.css`], { encoding: 'utf8' }) : null;
async function settle(page, root, active = false) {
  await page.waitForTimeout(80);
  await root.evaluate(async (el, active) => {
    const ancestors = []; for (let p = active ? document.activeElement : el; p; p = p.parentElement) ancestors.push(p);
    let previous = '', stable = 0;
    for (let i = 0; i < 120; i++) {
      await new Promise(requestAnimationFrame);
      const current = ancestors.map(p => `${p.scrollTop},${p.scrollLeft}`).join(';');
      stable = current === previous ? stable + 1 : 0; previous = current;
      if (stable >= 4) return;
    }
    throw Error('Scroll positions did not settle');
  }, active);
}
let focusDefects = [];
async function reach(page, text) {
  for (let i = 0; i < 40; i++) {
    await page.keyboard.press('Tab');
    if (await page.evaluate(t => document.activeElement?.textContent.trim() === t, text)) return;
  }
  assert.fail(`Natural Tab failed to reach ${text}`);
}
async function ring(page, stage = '') {
  await settle(page, page.locator('body'), true); // Observe native keyboard scrolling; never move it.
  const check = await page.evaluate(() => {
    const el = document.activeElement, s = getComputedStyle(el), r = el.getBoundingClientRect();
    const extra = Math.max(0, parseFloat(s.outlineWidth) + parseFloat(s.outlineOffset));
    const defects = [];
    if (s.outlineStyle === 'none' || !extra) defects.push('missing focus outline');
    if (r.top - extra < 0 || r.left - extra < 0 || r.right + extra > innerWidth || r.bottom + extra > innerHeight) defects.push('viewport clips ring');
    for (let p = el.parentElement; p; p = p.parentElement) {
      const c = getComputedStyle(p), b = p.getBoundingClientRect();
      if (/(auto|scroll|hidden|clip)/.test(c.overflowY) && (r.top - extra < b.top - 1 || r.bottom + extra > b.bottom + 1)) defects.push(`vertical ring clipped by ${p.className}`);
      if (/(auto|scroll|hidden|clip)/.test(c.overflowX) && (r.left - extra < b.left - 1 || r.right + extra > b.right + 1)) defects.push(`horizontal ring clipped by ${p.className}`);
      if (p.tagName === 'DIALOG' && p.open) break; // Native top-layer content escapes ancestor clipping.
    }
    return { text: el.textContent.trim(), defects, rect: r.toJSON(), extra, margin: s.scrollMargin, windowY: scrollY, viewportTop: visualViewport.offsetTop };
  });
  if (check.defects.length) focusDefects.push({stage,...check}); return check.text;
}
async function fullText(page, root) {
  const expected = new Set(), seen = new Set(), defects = new Set(), lineboxWarnings = new Set();
  const box = await root.boundingBox(); await page.mouse.move(box.x + box.width / 2, Math.min(page.viewportSize().height - 20, box.y + box.height - 20));
  await page.mouse.wheel(0, -10000); await settle(page, root);
  const start = await root.evaluate(el => el.scrollTop); let end = start;
  for (let step = 0; step < 60; step++) {
    const scan = await root.evaluate(root => {
      const rows = [], faults = [], walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT); let n, index = 0;
      while ((n = walker.nextNode())) {
        if (!n.textContent.trim()) continue;
        const el = n.parentElement, s = getComputedStyle(el), range = document.createRange(); range.selectNode(n); index++;
        const rects = [...range.getClientRects()];
        if (!rects.length || s.visibility !== 'visible') faults.push(`hidden text: ${n.textContent.trim()}`);
        if (parseFloat(s.fontSize) < 10.99) faults.push(`below floor: ${n.textContent.trim()}`);
        if (s.textOverflow === 'ellipsis') faults.push(`ellipsis: ${n.textContent.trim()}`);
        rects.forEach((r, j) => {
          let visible = r.left >= -.5 && r.right <= innerWidth + .5 && r.top >= -.5 && r.bottom <= innerHeight + .5;
          for (let p = el; p; p = p.parentElement) {
            const c = getComputedStyle(p), b = p.getBoundingClientRect();
            if (/(auto|scroll|hidden|clip)/.test(c.overflowX) && (r.left < b.left - 1 || r.right > b.right + 1)) visible = false;
            if (/(auto|scroll|hidden|clip)/.test(c.overflowY) && (r.top < b.top - 1 || r.bottom > b.bottom + 1)) visible = false;
            if (p.tagName === 'DIALOG' && p.open) break;
          }
          rows.push({ key: `${index}:${j}`, visible, text: n.textContent.trim(), x: r.x, y: r.y, right: r.right, bottom: r.bottom });
        });
      }
      const visible = rows.filter(r => r.visible);
      for (let a = 0; a < visible.length; a++) for (let b = a + 1; b < visible.length; b++) {
        const x = visible[a], y = visible[b];
        if (Math.min(x.right, y.right) - Math.max(x.x, y.x) > .8 && Math.min(x.bottom, y.bottom) - Math.max(x.y, y.y) > .8) faults.push(`intersect: ${x.text} / ${y.text}`);
      }
      return { rows, faults };
    });
    for (const r of scan.rows) { expected.add(r.key); if (r.visible) seen.add(r.key); }
    for (const d of scan.faults) (d.startsWith('intersect:') ? lineboxWarnings : defects).add(d);
    if (defects.size || (step && seen.size === expected.size)) break;
    await page.mouse.wheel(0, 110); await settle(page, root); end = await root.evaluate(el => el.scrollTop);
  }
  assert.deepEqual([...defects], [], 'No hidden, truncated or under-floor text');
  assert.equal(seen.size, expected.size, 'Wheel reveals every complete text rectangle');
  return { fragments: expected.size, scrollStart: start, scrollEnd: end, lineboxWarnings: [...lineboxWarnings] };
}
(async () => {
  const browser = await chromium.launch(), results = [], errors = [];
  try {
    for (const theme of process.env.THEME ? [process.env.THEME] : ['light', 'dark']) for (const width of process.env.WIDTH ? [+process.env.WIDTH] : [450, 501, 900]) {
      const page = await browser.newPage({ viewport: { width, height: width === 900 ? 600 : 300 }, colorScheme: theme, reducedMotion: 'reduce' });
      focusDefects = [];
      page.on('pageerror', e => errors.push(e.message)); page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
      let stage = 'entry';
      try {
        await page.goto(process.env.APP_URL || 'http://127.0.0.1:1438');
        if (style) await page.evaluate(bodyStyle => {
          const sheet = [...document.querySelectorAll('style[data-vite-dev-id]')].find(s => s.dataset.viteDevId.endsWith('/views/PrivacyView.css'));
          if (!sheet) throw Error('Expected served Privacy stylesheet');
          const productionMargin = sheet.textContent.match(/\.privacy-heading > button \{[^}]*\}/)?.[0];
          if (!productionMargin) throw Error('Missing served production opener margin');
          const boundary = '\n.privacy-board {';
          sheet.textContent = `${sheet.textContent.slice(0, sheet.textContent.indexOf(boundary))}${bodyStyle.slice(bodyStyle.indexOf(boundary))}\n${productionMargin}`; // Preserve current rail; replace only frozen body, including deleted declarations.
        }, style);
        assert.equal(await page.title(), 'Kaydence'); assert.equal(await page.locator('vite-error-overlay').count(), 0);
        await reach(page, 'Privacy'); await page.keyboard.press('Enter'); const board = page.locator('.privacy-board'); assert(await board.isVisible());
        const text = await fullText(page, board); await page.screenshot({ path: `${dir}/independent-${theme}-${width}-end.png` });
        stage = 'open'; await reach(page, 'Privacy Constitution'); await ring(page,stage); await page.screenshot({ path: `${dir}/opener-${theme}-${width}.png` }); await page.keyboard.press('Enter');
        const dialog = page.locator('.privacy-dialog'); assert(await dialog.isVisible());
        assert(await page.getByRole('dialog').evaluate(el => el.contains(document.activeElement)));
        if (!await page.evaluate(() => document.activeElement.textContent.trim() === 'Close')) await page.keyboard.press('Tab');
        stage = 'initial-close'; assert.equal(await ring(page,stage), 'Close');
        stage = 'dialog-wheel'; const dialogText = await fullText(page, dialog); stage = 'close-after-wheel'; await page.keyboard.press('Tab'); assert.equal(await ring(page,stage), 'Close');
        await page.screenshot({ path: `${dir}/independent-${theme}-${width}-close.png` }); await page.keyboard.press('Enter'); assert.equal(await page.getByRole('dialog').count(), 0);
        stage = 'return'; assert.equal(await ring(page,stage), 'Privacy Constitution'); await page.keyboard.press('Enter'); stage = 'reopen-shift-tab'; await page.keyboard.press('Shift+Tab'); assert.equal(await ring(page,stage), 'Close');
        await page.keyboard.press('Escape'); assert.equal(await ring(page,'escape-return'), 'Privacy Constitution');
        await page.keyboard.press('Tab'); assert.equal(await ring(page,'setup'), 'Review in Setup'); await page.keyboard.press('Tab'); assert.equal(await ring(page,'history'), 'View History');
        assert(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
        results.push({ theme, width, status: focusDefects.length ? 'FAIL' : 'PASS', text, dialogText, focusDefects });
      } catch (e) { await page.screenshot({ path: `${dir}/failure-${theme}-${width}.png` }); results.push({ theme, width, status: 'FAIL', stage, reason: e.message, focusDefects }); }
      await page.close();
    }
  } finally { await browser.close(); }
  fs.writeFileSync(`${dir}/independent.json`, JSON.stringify({ results, errors }, null, 2)); console.log(JSON.stringify({ results, errors }, null, 2));
  assert.deepEqual(errors, []); assert(results.every(r => r.status === 'PASS'));
})().catch(e => { console.error(e); process.exitCode = 1; });
